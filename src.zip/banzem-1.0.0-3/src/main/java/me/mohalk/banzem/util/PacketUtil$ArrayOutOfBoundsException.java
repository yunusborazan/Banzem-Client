package me.mohalk.banzem.util;

public class PacketUtil$ArrayOutOfBoundsException
        extends RuntimeException {
}

